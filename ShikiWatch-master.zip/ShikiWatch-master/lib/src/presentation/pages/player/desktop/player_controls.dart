import 'package:flutter/material.dart';

import 'package:hooks_riverpod/hooks_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../../utils/extensions/buildcontext.dart';
import '../domain/player_provider_parameters.dart';
import '../../../providers/settings_provider.dart';
import '../shared/audio_video_progress_bar.dart';
import '../shared/skip_fragment_button.dart';
import '../shared/animated_play_pause.dart';
import '../shared/quality_popup_menu.dart';
import '../shared/player_speed_popup.dart';
import '../shared/next_ep_countdown.dart';
import '../../../widgets/auto_hide.dart';
import '../shared/player_settings.dart';
import '../shaders_provider.dart';
import '../player_provider.dart';

import 'components/player_info_header.dart';
import 'components/player_volume_slider.dart';

class DesktopPlayerControls extends ConsumerWidget {
  const DesktopPlayerControls(this.p, {super.key});

  final PlayerProviderParameters p;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Focus(
      autofocus: true,
      child: _UiGestures(
        providerParameters: p,
        child: Stack(
          clipBehavior: Clip.none,
          alignment: Alignment.topLeft,
          children: [
            const Positioned.fill(child: ColoredBox(color: Colors.black54)),
            Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  IconButton(
                    onPressed: () => ref
                        .read(playerPageProvider(p))
                        .toggleDFullscreen(p: true)
                        .then((value) => GoRouter.of(context).pop()),
                    padding: const EdgeInsets.all(0),
                    icon: const Icon(Icons.arrow_back),
                    color: Colors.white,
                    iconSize: 24.0,
                    tooltip: 'Назад',
                  ),
                  const Spacer(),
                  _PlayerInfoHeader(p),
                  const SizedBox(
                    height: 24,
                  ),
                  _ProgressBar(p),
                  _PlayerBottom(p),
                ],
              ),
            ),
            Align(
              child: _AutoplayNextEp(p),
            ),
          ],
        ),
      ),
    );
  }
}

class _AutoplayNextEp extends ConsumerWidget {
  const _AutoplayNextEp(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasNextEp = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.hasNextEp));
    final completed = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.completed));

    final currentNumber = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.currentEpNumber));

    final bool playerNextEpisode = ref.watch(
        settingsProvider.select((settings) => settings.playerNextEpisode));

    if (!playerNextEpisode) {
      return const SizedBox.shrink();
    }

    if (!(hasNextEp && completed)) {
      return const SizedBox.shrink();
    }

    return NextEpisodeCountdown(
      number: currentNumber + 1,
      onCancel: () {
        ref
            .read(playerPageProvider(providerParameters))
            .onPlayerCompleted(false);
        ref
            .read(playerPageProvider(providerParameters))
            .hideController
            .toggle();
      },
      onPlay: () {
        ref
            .read(playerPageProvider(providerParameters))
            .changeEpisode(currentNumber + 1);
        ref
            .read(playerPageProvider(providerParameters))
            .hideController
            .toggle();
      },
    );
  }
}

class _PlayerBottom extends ConsumerWidget {
  const _PlayerBottom(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _VolumeSlider(providerParameters),
        Expanded(
          child: Align(
            alignment: Alignment.center,
            child: _PlaybackControls(providerParameters),
          ),
        ),
        Expanded(
          child: Align(
            alignment: Alignment.centerRight,
            child: _OtherControls(providerParameters),
          ),
        ),
      ],
    );
  }
}

class _OtherControls extends ConsumerWidget {
  const _OtherControls(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final (init, error) =
        ref.watch(playerPageProvider(providerParameters).select((value) => (
              value.init,
              value.error,
            )));

    final (playbackSpeed) =
        ref.watch(playerStateProvider.select((s) => (s.playbackSpeed)));

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (init && !error) ...[
          PlayerSpeedPopUp(
            playbackSpeed: playbackSpeed,
            onSelected: ref
                .read(playerPageProvider(providerParameters))
                .setPlaybackSpeed,
          ),
          Consumer(
            builder: (context, ref, child) {
              final (playableContent, selectedQuality) = ref.watch(
                  playerPageProvider(providerParameters).select((value) => (
                        value.playableContent,
                        value.selectedQuality,
                      )));

              return QualityPopUpMenu(
                playableContent: playableContent,
                selectedQuality: selectedQuality,
                onSelected: (q) => ref
                    .read(playerPageProvider(providerParameters))
                    .changeQuality(q),
                onOpened: () {},
                onCanceled: () {},
              );
            },
          ),
          // if (Platform.isWindows) _ShadersButton(providerParameters),
          _ShadersButton(providerParameters),
        ],
        IconButton(
          tooltip: 'Полноэкранный режим',
          icon: const Icon(Icons.fullscreen),
          color: Colors.white,
          iconSize: 24.0,
          onPressed: () => ref
              .read(playerPageProvider(providerParameters))
              .toggleDFullscreen(),
        ),
      ],
    );
  }
}

class _ShadersButton extends ConsumerWidget {
  const _ShadersButton(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final activeShaders = ref.watch(activeShadersProvider);

    return IconButton(
      tooltip: 'Anime4K шейдеры',
      icon:
          Icon(activeShaders.isNotEmpty ? Icons.four_k : Icons.four_k_outlined),
      iconSize: 24.0,
      color: Colors.white,
      onPressed: () => ShaderSelectorWidget.show(context),
    );
  }
}

class _VolumeSlider extends ConsumerWidget {
  const _VolumeSlider(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final (player, volume) =
        ref.watch(playerStateProvider.select((s) => (s.player, s.volume)));

    return PlayerVolumeSlider(
      volume,
      onChange: (d) {
        ref.read(playerPageProvider(providerParameters)).saveVolume(d);
        player.setVolume(d);
      },
    );
  }
}

class _PlaybackControls extends ConsumerWidget {
  const _PlaybackControls(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final (player, playing) =
        ref.watch(playerStateProvider.select((s) => (s.player, s.playing)));

    final (hasPrevEp, hasNextEp) = ref.watch(
        playerPageProvider(providerParameters)
            .select((value) => (value.hasPrevEp, value.hasNextEp)));

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        IconButton(
          tooltip: 'Предыдущая серия',
          onPressed: hasPrevEp
              ? () {
                  final currentEpNumber = ref
                      .read(playerPageProvider(providerParameters))
                      .currentEpNumber;

                  ref
                      .read(playerPageProvider(providerParameters))
                      .changeEpisode(currentEpNumber - 1);
                }
              : null,
          color: Colors.white,
          iconSize: 32.0,
          icon: const Icon(Icons.skip_previous),
        ),
        const SizedBox(
          width: 24.0,
        ),
        IconButton(
          color: Colors.white,
          iconSize: 48.0,
          icon: AnimatedPlayPause(
            playing: playing,
            color: Colors.white,
          ),
          onPressed: player.playOrPause,
        ),
        const SizedBox(
          width: 24.0,
        ),
        IconButton(
          tooltip: 'Следующая серия',
          onPressed: hasNextEp
              ? () {
                  final currentEpNumber = ref
                      .read(playerPageProvider(providerParameters))
                      .currentEpNumber;

                  ref
                      .read(playerPageProvider(providerParameters))
                      .changeEpisode(currentEpNumber + 1);
                }
              : null,
          color: Colors.white,
          iconSize: 32.0,
          icon: const Icon(Icons.skip_next),
        ),
      ],
    );
  }
}

class _PlayerInfoHeader extends ConsumerWidget {
  const _PlayerInfoHeader(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final extra = providerParameters.extra;

    final currentEpNumber = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.currentEpNumber));

    final studioName = extra.studio.name
        .replaceFirst('.Subtitles', ' (Субтитры)')
        .replaceFirst('|Субтитры', ' (Субтитры)');

    return PlayerInfoHeader(
      animeName: extra.titleInfo.animeName,
      animePicture: extra.titleInfo.imageUrl,
      episodeNumber: currentEpNumber,
      studioName: studioName,
      skipButton: _SkipButton(providerParameters),
      titleId: extra.titleInfo.shikimoriId,
    );
  }
}

class _SkipButton extends ConsumerWidget {
  const _SkipButton(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final opTimecode = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.opTimecode));

    final (player, position, duration) = ref.watch(
        playerStateProvider.select((s) => (s.player, s.position, s.duration)));

    final showSkip = duration.inSeconds > 0 &&
        opTimecode.length == 2 &&
        (opTimecode.first) <= position.inSeconds &&
        opTimecode.last > position.inSeconds;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: showSkip
          ? IgnorePointer(
              ignoring: !showSkip,
              child: SkipFragmentButton(
                title: 'Пропустить опенинг',
                onSkip: () => player.seek(Duration(seconds: opTimecode.last)),
                onClose: () => ref
                    .read(playerPageProvider(providerParameters))
                    .opTimecode = [],
              ),
            )
          : IconButton(
              tooltip: 'Перемотать 85 секунд',
              iconSize: 32,
              color: Colors.white,
              onPressed: () => player.seek(
                position + const Duration(seconds: 85),
              ),
              icon: const Icon(Icons.double_arrow_rounded),
            ),
    );
  }
}

class _ProgressBar extends ConsumerWidget {
  const _ProgressBar(this.providerParameters);

  final PlayerProviderParameters providerParameters;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final (player, position, duration, buffer) = ref.watch(playerStateProvider
        .select((s) => (s.player, s.position, s.duration, s.buffer)));
    final hideController = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.hideController));

    final opTimecode = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.opTimecode));

    return ProgressBar(
      progress: position,
      total: duration,
      buffered: buffer,
      thumbRadius: 8,
      timeLabelPadding: 4,
      timeLabelTextStyle: const TextStyle(
        color: Colors.white,
      ),
      thumbGlowRadius: 24,
      onSeek: player.seek,
      // onDragUpdate: (_) {
      //   if (notifier.hideController.isVisible) {
      //     notifier.hideController.show();
      //   }
      // },
      onDragStart: (details) {
        hideController.cancel();
        hideController.permShow();
      },
      onDragEnd: () {
        hideController.hide();
      },
      timecodeMarkerColor: context.colorScheme.error,
      timecodeRanges: opTimecode.length == 2
          ? [
              (
                start: Duration(seconds: opTimecode.first),
                end: Duration(seconds: opTimecode.last)
              ),
            ]
          : null,
    );
  }
}

class _UiGestures extends ConsumerWidget {
  const _UiGestures({
    required this.providerParameters,
    required this.child,
  });

  final PlayerProviderParameters providerParameters;
  final Widget child;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final player = ref.watch(playerStateProvider.select((s) => s.player));
    final hideController = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.hideController));
    final completed = ref.watch(playerPageProvider(providerParameters)
        .select((value) => value.completed));

    return GestureDetector(
      onTap: player.playOrPause,
      child: MouseRegion(
        onHover: (_) {
          if (completed) {
            return;
          }
          hideController.show();
        },
        onEnter: (_) {
          if (completed) {
            return;
          }
          hideController.show();
        },
        onExit: (_) {
          if (completed) {
            return;
          }
          hideController.hide();
        },
        child: AutoHide(
          controller: hideController,
          switchDuration: const Duration(milliseconds: 500),
          child: child,
        ),
      ),
    );
  }
}
